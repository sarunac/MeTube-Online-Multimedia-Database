<div id="nav">

<a href='browse.php'> Home </a>
	<a href='userhome.php'> About</a>
	<a href='groups.php'> Discussions </a>
	<a href='friend.php'> Contacts </a>
	<a href='inbox.php'> Messages </a>
	<a href='userhome.php'> Profile Update </a>
	<a href='media_upload1.php'> Upload </a>
<a href='playlist.php'> Playlist </a>
<a href='channel.php'>Channels</a>
<a href='mysubscriptions.php'>My subscriptions</a>


	
<div id="search">
<?php //include('includes/search.php');?>
</div>
</div> <!-- end #nav -->

