<form class="search-form" action="search2.php" method="get"
   name="searchForm">
SEARCH : <input type="TEXT" name="search_query" value=" Type the name of the media..! "
onClick="this.value='';this.onclick=null;" size="50" maxlength="100"
align="center"/>
 <span class="masthead-button-wrapper"><a href="#"
onclick="document.searchForm.submit(); return false;">
 <input type="button" name="searchbutton" value="Search" align="center"/>
 </a></span>
<a href="advancesearch.php">Click here for advance search</a>
</form>
