<?php

$dbhost = "mmlab.cs.clemson.edu";
$dbuser = "g6";
$dbpass = "metubeftw";
$database = "g6";
?>
