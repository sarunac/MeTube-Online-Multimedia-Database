

<div id="sidebar">

	<h3>Navigation</h3>

    <li><a href="index.php">Home</a></li>

    <li><a href="about.php">About Us</a></li>

    <li><a href="#">Links</a></li>

    <li><a href="#">Portfolio</a></li>

    <li><a href="#">Contact</a></li>

 

<h3>Box Two</h3>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

 

<h3>Box Three</h3>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>

    <li><a href="#">Link Here</a></li>



</div> <!-- end #sidebar -->

