<?php
/**
 * @author Marijan Šuflaj <msufflaj32@gmail.com>
 * @link http://www.php4every1.com
 */

$con = mysql_connect('localhost', 'root', '');
mysql_select_db('g6', $con);
 ?>
//include 'mysqlClass.inc.php';

//$con = $db;