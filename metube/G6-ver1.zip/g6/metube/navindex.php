<div id="navindex">
<div id="searchindex">
<?php include('search.php');?>
</div>
</div> <!-- end #nav -->


